package bll;

import bo.Game;
import bo.Player;
import dal.GameDAO;
import dal.PlayerDAO;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GameService {

    private final PlayerDAO playerDAO;
    private final GameDAO gameDAO;

    public GameService() {
        this.playerDAO = new PlayerDAO();
        this.gameDAO = new GameDAO();
    }

    
    public Player processWinLoss(Player winner, Player loser) {
        playerDAO.incrementWins(winner.getUsername());
        playerDAO.incrementLosses(loser.getUsername());

        Game gameRecord = new Game();
        gameRecord.setPlayer1(winner.getUsername()); 
        gameRecord.setPlayer2(loser.getUsername());
        gameRecord.setWinner(winner.getUsername());

        String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        gameRecord.setDate(currentDate);

        gameDAO.saveGame(gameRecord);
        return playerDAO.getPlayerByUsername(winner.getUsername());
    }
    

    
    public void processDraw(Player player1, Player player2) {
        playerDAO.incrementDraws(player1.getUsername());
        playerDAO.incrementDraws(player2.getUsername());

        Game gameRecord = new Game();
        gameRecord.setPlayer1(player1.getUsername());
        gameRecord.setPlayer2(player2.getUsername());
        gameRecord.setWinner(null); 

        String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        gameRecord.setDate(currentDate);

        gameDAO.saveGame(gameRecord);
    }
}