package bll;

import bo.Player;
import dal.PlayerDAO;

public class Authentification{
	private final PlayerDAO playerDAO = new PlayerDAO();
	public boolean login(String username ,String password) {
		Player player = playerDAO.getPlayerByUsername(username);
		if(player != null) {
			return player.getPassword().equals(password);
		}
		return false;
	}
	public boolean inscription(String username , String password) {
		Player existing = playerDAO.getPlayerByUsername(username);
		if(existing != null) {
			System.out.println("ce nom existe deja");
			return false;
		}
		Player p=new Player();
		p.setUsername(username);
		p.setPassword(password);
		p.setWins(0);
		p.setLosses(0);
		p.setDraws(0);
		return playerDAO.insertPlayer(p);
	}
	
}