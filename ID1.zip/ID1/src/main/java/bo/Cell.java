package bo;

public class Cell {

    public enum Type {
        NORMAL, RIVIERE, PIEGE, SANCTUAIRE
    }

    private int row;
    private int col;
    private Type type;
    private Animal animal; // peut être null

    public Cell(int row, int col, Type type) {
        this.row = row;
        this.col = col;
        this.type = type;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
    public Type getType() { return type; }

    public void setType(Type type) {
        this.type = type;
    }

    public Animal getAnimal() { return animal; }
    public void setAnimal(Animal animal) { this.animal = animal; }

    public boolean isEmpty() {
        return animal == null;
    }

    public boolean isRiver() {
        return type == Type.RIVIERE;
    }

    public boolean isTrap() {
        return type == Type.PIEGE;
    }

    public boolean isSanctuary() {
        return type == Type.SANCTUAIRE;
    }
}
