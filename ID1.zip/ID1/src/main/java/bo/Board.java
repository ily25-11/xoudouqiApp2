package bo;

public class Board {

    private final int ROWS = 9;
    private final int COLS = 7;
    private Cell[][] grid;

    public Board() {
        grid = new Cell[ROWS][COLS];
        initializeBoard();
        placeStartingAnimals();
    }

    private void initializeBoard() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                grid[i][j] = new Cell(i, j, Cell.Type.NORMAL);
            }
        }

        for (int i = 3; i <= 5; i++) {
            grid[i][1].setType(Cell.Type.RIVIERE);
            grid[i][2].setType(Cell.Type.RIVIERE);
            grid[i][4].setType(Cell.Type.RIVIERE);
            grid[i][5].setType(Cell.Type.RIVIERE);
        }

        grid[0][2].setType(Cell.Type.PIEGE);
        grid[0][4].setType(Cell.Type.PIEGE);
        grid[1][3].setType(Cell.Type.PIEGE);
        grid[7][3].setType(Cell.Type.PIEGE);
        grid[8][2].setType(Cell.Type.PIEGE);
        grid[8][4].setType(Cell.Type.PIEGE);

        grid[0][3].setType(Cell.Type.SANCTUAIRE);
        grid[8][3].setType(Cell.Type.SANCTUAIRE);
    }

    public void placeStartingAnimals() {
        grid[8][0].setAnimal(new Tiger("J1"));
        grid[8][6].setAnimal(new Lion("J1"));
        grid[7][1].setAnimal(new Cat("J1"));
        grid[7][5].setAnimal(new Dog("J1"));
        grid[6][0].setAnimal(new Elephant("J1"));
        grid[6][2].setAnimal(new Wolf("J1"));
        grid[6][4].setAnimal(new Leopard("J1"));
        grid[6][6].setAnimal(new Rat("J1"));

        grid[0][0].setAnimal(new Lion("J2"));
        grid[0][6].setAnimal(new Tiger("J2"));
        grid[1][1].setAnimal(new Cat("J2"));
        grid[1][5].setAnimal(new Dog("J2"));
        grid[2][0].setAnimal(new Rat("J2"));
        grid[2][2].setAnimal(new Leopard("J2"));
        grid[2][4].setAnimal(new Wolf("J2"));
        grid[2][6].setAnimal(new Elephant("J2"));
    }

    public Cell getCell(int row, int col) {
        return grid[row][col];
    }

    private boolean isRiver(int row, int col) {
        return isValid(row, col) && grid[row][col].isRiver();
    }

    private boolean isValid(int row, int col) {
        return row >= 0 && row < ROWS && col >= 0 && col < COLS;
    }

    public boolean moveAnimal(int fromRow, int fromCol, int toRow, int toCol, String currentTurn) {
        if (!isValid(fromRow, fromCol) || !isValid(toRow, toCol)) {
            System.out.println("Coordonnées invalides.");
            return false;
        }

        Cell from = getCell(fromRow, fromCol);
        Cell to = getCell(toRow, toCol);

        if (from.isEmpty()) {
            System.out.println("Aucun animal ici.");
            return false;
        }

        Animal moving = from.getAnimal();

        if (!moving.getOwner().equals(currentTurn)) {
            System.out.println("Ce n'est pas votre pièce.");
            return false;
        }

     // Interdire l’entrée dans son propre sanctuaire uniquement
        if (to.isSanctuary()) {
            if ((currentTurn.equals("J1") && to.getRow() == 8 && to.getCol() == 3) ||
                (currentTurn.equals("J2") && to.getRow() == 0 && to.getCol() == 3)) {
                System.out.println("Tu peux pas entrer dans ton propre sanctuaire.");
                return false;
            }
        }


        int dx = toRow - fromRow;
        int dy = toCol - fromCol;
        int distance = Math.abs(dx) + Math.abs(dy);

        // Lion et Tigre sautent la rivière
        if ((moving instanceof Lion || moving instanceof Tiger) && distance > 1) {
            if (dx != 0 && dy == 0) { // mouvement vertical
                int step = dx > 0 ? 1 : -1;
                for (int r = fromRow + step; r != toRow; r += step) {
                    if (!isRiver(r, fromCol) || (grid[r][fromCol].getAnimal() instanceof Rat)) {
                        System.out.println("Saut bloqué par un rat ou terrain non valide.");
                        return false;
                    }
                }
            } else if (dy != 0 && dx == 0) { // mouvement horizontal
                int step = dy > 0 ? 1 : -1;
                for (int c = fromCol + step; c != toCol; c += step) {
                    if (!isRiver(fromRow, c) || (grid[fromRow][c].getAnimal() instanceof Rat)) {
                        System.out.println("Saut bloqué par un rat ou terrain non valide.");
                        return false;
                    }
                }
            } else {
                System.out.println("Déplacement invalide.");
                return false;
            }
        } else if (distance != 1) {
            System.out.println("Déplacement trop long (sauf saut lion/tigre).");
            return false;
        }

        if (!(moving instanceof Rat) && to.isRiver()) {
            System.out.println("Seul le rat peut entrer dans la rivière.");
            return false;
        }

        if (!to.isEmpty()) {
            Animal target = to.getAnimal();
            if (target.getOwner().equals(moving.getOwner())) {
                System.out.println("Tu peux pas capturer ton propre animal.");
                return false;
            }

            int effectiveRank = to.isTrap() ? 0 : target.getRank();

            if (moving instanceof Rat && from.isRiver() && !to.isRiver()) {
                System.out.println("Le rat ne peut pas capturer en sortant de l'eau.");
                return false;
            }

            if (!(moving instanceof Elephant) && moving.getRank() < effectiveRank && !(moving instanceof Rat && target instanceof Elephant)) {
                System.out.println("Capture impossible : pas assez puissant.");
                return false;
            }

            System.out.println("Bien joué , Capture réussie !");
        }

        to.setAnimal(moving);
        from.setAnimal(null);

//        if (to.isSanctuary()) {
//            if ((currentTurn.equals("J1") && to.getRow() == 0 && to.getCol() == 3) ||
//                (currentTurn.equals("J2") && to.getRow() == 8 && to.getCol() == 3)) {
//            	System.out.println("============================================================================================================================");
//                System.out.println("OOOOOO !!! Bravo " + (currentTurn.equals("J1") ? Main.getJoueur1().getUsername() : Main.getJoueur2().getUsername()) + " ! Tu as gagné !");
//            	System.out.println("============================================================================================================================");
//                System.exit(0);
//            }
//        }
		return true;

    }
    private String getEmoji(Animal a) {
        return switch (a.getName().toLowerCase()) {
            case "rat" -> "🐀";
            case "cat" -> "🐱";
            case "dog" -> "🐶";
            case "wolf" -> "🐺";
            case "leopard" -> "🐆";
            case "tiger" -> "🐯";
            case "lion" -> "🦁";
            case "elephant" -> "🐘";
            default -> "❓";
        };
    }


    public void printBoard() {
        System.out.println("     0   1   2   3   4   5   6");
        System.out.println("   +---+---+---+---+---+---+---+");

        for (int i = 0; i < 9; i++) {
            System.out.print(" " + i + " |");
            for (int j = 0; j < 7; j++) {
                Cell c = grid[i][j];
                String symbol;

                if (c.getAnimal() != null) {
                    symbol = getEmoji(c.getAnimal()) + c.getAnimal().getOwner().substring(1);
                } else if (c.isRiver()) {
                    symbol = " ~ ";
                } else if (c.isTrap()) {
                    symbol = " T ";
                } else if (c.isSanctuary()) {
                    symbol = " S ";
                } else {
                    symbol = "   ";
                }

                System.out.print(symbol + "|");
            }
            System.out.println();
            System.out.println("   +---+---+---+---+---+---+---+");
        }
    }
    private int countPiecesFor(String player) {
        int count = 0;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (!grid[i][j].isEmpty() && player.equals(grid[i][j].getAnimal().getOwner())) {
                    count++;
                }
            }
        }
        return count;
    }

    public String getWinner() {
        Cell j2Sanctuary = grid[0][3];
        if (!j2Sanctuary.isEmpty() && "J1".equals(j2Sanctuary.getAnimal().getOwner())) {
            return "J1";
        }
        
        Cell j1Sanctuary = grid[8][3];
        if (!j1Sanctuary.isEmpty() && "J2".equals(j1Sanctuary.getAnimal().getOwner())) {
            return "J2";
        }
        if (countPiecesFor("J1") == 0) {
            return "J2";
        }
        if (countPiecesFor("J2") == 0) {
            return "J1"; 
        }

        return null;
		
} }
