package bo;

public class Dog extends Animal {
    public Dog(String owner) {
        this.rank = 4;
        this.name = "Dog";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank;
    }
}
