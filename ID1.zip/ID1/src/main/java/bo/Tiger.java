package bo;

public class Tiger extends Animal{
	
	public Tiger(String owner) {
		this.rank=6;
		this.name = "Tiger";
		this.canSwim = false;
		this.owner = owner;
		}
	@Override
	public boolean canCapture(Animal target) {
		return target.getRank()<= this.rank;
	}

}
