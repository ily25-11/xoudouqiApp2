package bo;

public abstract class Animal {
	protected int rank;
    protected String name;
    protected boolean canSwim;
    protected String owner; // J1 ou J2

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public boolean canSwim() {
        return canSwim;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    // Règle de capture générale à surcharger
    public abstract boolean canCapture(Animal target);


}
