package bo;

public class Lion extends Animal {
    public Lion(String owner) {
        this.rank = 7;
        this.name = "Lion";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank;
    }
}
