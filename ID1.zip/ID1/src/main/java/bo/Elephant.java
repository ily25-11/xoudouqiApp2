package bo;

public class Elephant extends Animal {
    public Elephant(String owner) {
        this.rank = 8;
        this.name = "Elephant";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return !(target instanceof Rat) && target.getRank() <= this.rank;
    }
}
