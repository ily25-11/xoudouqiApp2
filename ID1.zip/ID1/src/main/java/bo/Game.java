package bo;

public class Game {
	private int id;
	private String player1;
	private String player2;
	private String winner;
	private String date;
	
	public int getID() {
		return id;
	}
	public String getPlayer1() {
		return player1;
	}
	public String getPlayer2() {
		return player2;
	}
	public String getWinner() {
		return winner;
	}
	public String getDate() {
		return date;
	}
	
	public void setID(int id) {
		this.id=id;
	}
	public void setPlayer1(String player1) {
		this.player1=player1;
	}
	public void setPlayer2(String player2) {
		this.player2=player2;
	}
	public void setWinner(String winner) {
		this.winner=winner;
	}
	public void setDate(String date) {
		this.date=date;
	}
	
	

}
