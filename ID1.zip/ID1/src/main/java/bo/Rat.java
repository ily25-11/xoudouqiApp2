package bo;

public class Rat extends Animal {
    public Rat(String owner) {
        this.rank = 1;
        this.name = "Rat";
        this.canSwim = true;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank || target instanceof Elephant;
    }
}
