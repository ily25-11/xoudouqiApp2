package bo;

public class Leopard extends Animal {
    public Leopard(String owner) {
        this.rank = 5;
        this.name = "Leopard";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank;
    }
}
