package bo;

public class Wolf extends Animal {
    public Wolf(String owner) {
        this.rank = 3;
        this.name = "Wolf";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank;
    }
}
