package bo;

public class Cat extends Animal {
    public Cat(String owner) {
        this.rank = 2;
        this.name = "Cat";
        this.canSwim = false;
        this.owner = owner;
    }

    @Override
    public boolean canCapture(Animal target) {
        return target.getRank() <= this.rank;
    }
}