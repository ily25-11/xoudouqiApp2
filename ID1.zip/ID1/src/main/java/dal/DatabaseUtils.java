package dal;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class DatabaseUtils {

	    private String url = "jdbc:sqlite:xoudouqi.db";
	    private static final String DRIVER_NAME ="org.sqlite.JDBC";
	    public static Connection con;

	    private DatabaseUtils() {

	        try {
	            Class.forName(DRIVER_NAME);
	        } catch (Exception e) {
	            throw new DatabaseException("Erreur lors du chargement du pilote SQlite", e);
	        }
	        try {
	            con = DriverManager.getConnection(url);
	        } catch (Exception e) {
	            e.printStackTrace();
	            throw new DatabaseException("Erreur lors de la connexion SQlite", e);
	        }
	    }

	    public static Connection getConnection() {
	        try {
	            if (con == null || con.isClosed() || !con.isValid(2)) {
	                new DatabaseUtils();
	            }
	        } catch (SQLException e) {
	            throw new DatabaseException("Erreur lors de la connexion", e);
	        }
	        return con;
	    }

	    public static void safelyResetAutoCommit() {
	        try {
	            if(con != null && !con.getAutoCommit()) {
	                con.setAutoCommit(true);
	            }
	        } catch (SQLException exAutoCommit) {
	            try {
	                con.close(); 
	            } catch (SQLException exClose) {

	                System.exit(-1);
	            }


	        }
	    }


	    public static void safelyCloseConnection() {
	        try {
	            if (con != null && !con.isClosed()) {
	                con.close();
	            }
	        } catch (SQLException ex) {
	            System.err.println("Erreur lors de la fermeture de la connexion.");
	        }
	    }


	}

