package dal;
    import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.Statement;

	public class DbInstaller {


	    public static boolean checkIfDbExist() {
	        try {
	            Connection connection = DatabaseUtils.getConnection();

	            String checkTableSQL = """
	                            SELECT name From sqlite_master
	                            WHERE type='table' AND name='players';
	                            """;

	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery(checkTableSQL);

	            return resultSet.next();

	        } catch (Exception ex) {
	            throw new DatabaseException("Erreur de vérification de l'installation", ex);
	        }
	    }
	   

	    public static boolean install() {
	        try {
	            Connection connection = DatabaseUtils.getConnection();
	            Statement statement = connection.createStatement();


	            String createPlayersTable = """
	                    CREATE TABLE IF NOT EXISTS players (
	                        username TEXT PRIMARY KEY ,
	                        password TEXT NOT NULL ,
	                        wins INTEGER DEFAULT 0,
	                        losses INTEGER DEFAULT 0,
	                        draws INTEGER DEFAULT 0
	                 );
	                 """;

	            String createGamesTable = """
	                    CREATE TABLE IF NOT EXISTS games (
	                        id INTEGER PRIMARY KEY,
	                        player1 TEXT NOT NULL,
	                        player2 TEXT NOT NULL,
	                        winner TEXT,
	                        date TEXT,
	                        FOREIGN KEY (player1) REFERENCES players(username),
	                        FOREIGN KEY (player2) REFERENCES players(username),
	                        FOREIGN KEY (winner)  REFERENCES players(username)
	                    );
	                    """;

	            statement.execute(createPlayersTable);
	            statement.execute(createGamesTable);
	           
	            return true;


	        } catch (Exception ex) {
	            throw new DatabaseException("Erreur lors de l'installation de la base de données", ex);
	        }
	    }
    
    public static void main(String[] args) {
        if (!DbInstaller.checkIfDbExist()) {
            DbInstaller.install();
            System.out.println("Tables créées !");
	        } else {
           System.out.println(" Les tables existent déjà.");
        }
    }}
	    
