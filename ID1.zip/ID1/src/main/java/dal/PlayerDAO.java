package dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bo.Player;

public class PlayerDAO {


    public Player getPlayerByUsername(String username) {
        String sql = "SELECT * FROM players WHERE username = ?";
        
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Player p = new Player();
                    p.setUsername(rs.getString("username"));
                    p.setPassword(rs.getString("password")); 
                    p.setWins(rs.getInt("wins"));
                    p.setLosses(rs.getInt("losses"));
                    p.setDraws(rs.getInt("draws"));
                    return p;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de la récupération du joueur", e);
        }
        return null; 
    }


    public boolean insertPlayer(Player p) { 
        String sql = "INSERT INTO players (username, password) VALUES (?, ?)";
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
             
            stmt.setString(1, p.getUsername());
            stmt.setString(2, p.getPassword());
            
            int rowsAffected = stmt.executeUpdate();
            
            return rowsAffected == 1;

        } catch (SQLException e) {
            return false;
        }
    }

   
    public void incrementWins(String username) {
        String sql = "UPDATE players SET wins = wins + 1 WHERE username = ?";
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de la mise à jour des victoires", e);
        }
    }

    
    public void incrementLosses(String username) {
        String sql = "UPDATE players SET losses = losses + 1 WHERE username = ?";
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de la mise à jour des défaites", e);
        }
    }
    public void incrementDraws(String username) {
        String sql = "UPDATE players SET draws = draws + 1 WHERE username = ?";
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de la mise à jour des défaites", e);
        }
    }
}