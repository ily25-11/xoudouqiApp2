package dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bo.Game; 

public class GameDAO {


    /**
     * Enregistre une nouvelle partie dans la base de données.
     * @param game L'objet Game contenant les informations de la partie.
     */
    public void saveGame(Game game) {
        String sql = "INSERT INTO games (player1, player2, winner, date) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

          
            stmt.setString(1, game.getPlayer1());
            stmt.setString(2, game.getPlayer2());
            stmt.setString(3, game.getWinner());
            stmt.setString(4, game.getDate());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de l'enregistrement de la partie", e);
        }
    }

    /**
     * Récupère toutes les parties jouées par un utilisateur donné.
     * @param username Le nom d'utilisateur du joueur.
     * @return Une liste de parties, triées de la plus récente à la plus ancienne.
     */
    public List<Game> getGamesByPlayer(String username) {
        List<Game> games = new ArrayList<>();
        String sql = """
                    SELECT * FROM games
                    WHERE player1 = ? OR player2 = ?
                    ORDER BY date DESC
                """;
        try (Connection connection = DatabaseUtils.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, username);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Game g = new Game();
                    
                    g.setID(rs.getInt("id"));
                    g.setPlayer1(rs.getString("player1"));
                    g.setPlayer2(rs.getString("player2"));
                    g.setWinner(rs.getString("winner"));
                    g.setDate(rs.getString("date"));
                    games.add(g);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erreur lors de la récupération des parties du joueur", e);
        }
        return games;
    }
}