package gui;

import bll.Authentification;
import bll.GameService;
import bo.Board;
import bo.Player;
import dal.DatabaseUtils;
import dal.PlayerDAO;

import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    private static Player joueur1 = null;
    private static Player joueur2 = null;

    public static Player loginPlayer(Scanner scanner, Authentification auth, String label) {
        PlayerDAO playerDAO = new PlayerDAO(); 
        while (true) {
            System.out.println("-----------------------------------------------");
            System.out.print("Nom d'utilisateur pour " + label + " :  ");
            String username = scanner.nextLine();
            System.out.println("-----------------------------------------------");
            System.out.print("Mot de passe :  ");
            String password = scanner.nextLine();
            System.out.println("-----------------------------------------------");

            if (auth.login(username, password)) {
                System.out.println("-----------------------------------------------");
                System.out.println("Connexion réussie pour " + username);
                System.out.println("-----------------------------------------------");

                Player loggedInPlayer = playerDAO.getPlayerByUsername(username);
                if (loggedInPlayer != null) {
                    return loggedInPlayer;
                } else {
                    System.out.println("Erreur critique : Impossible de charger les données pour " + username);
                }
            } else {
                System.out.println("Identifiants incorrects. Réessayer...");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Authentification auth = new Authentification();

        while (true) {
            System.out.println("-----------------------------------------------");
            System.out.println("|           Menu d'Authentification           |");
            System.out.println("-----------------------------------------------");
            System.out.println("|              1. Jouer                       |");
            System.out.println("|              2. S'inscrire                  |");
            System.out.println("|              3. Quitter                     |");
            System.out.println("-----------------------------------------------");
            System.out.print("        Votre choix  >> ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> {
                    System.out.println("================== Connexion du Joueur 1 ================== ");
                    setJoueur1(loginPlayer(scanner, auth, "Joueur 1"));
                    System.out.println("\n================== Connexion du Joueur 2 ==================");
                    setJoueur2(loginPlayer(scanner, auth, "Joueur 2"));

                    jouer(); 
                    return;
                }
                case "2" -> {
                    System.out.println("-----------------------------------------------");
                    System.out.print("Choisissez un nom d'utilisateur : ");
                    String username = scanner.nextLine();
                    System.out.println("-----------------------------------------------");
                    System.out.print("Choisissez un mot de passe : ");
                    String password = scanner.nextLine();
                    System.out.println("-----------------------------------------------");

                    if (auth.inscription(username, password)) {
                        System.out.println("Compte créé. Lancez à nouveau et cliquez sur 1 pour jouer.");
                        System.out.println("          ******************************                ");
                    } else {
                        System.out.println("Le nom est déjà utilisé. Essayez un autre.");
                    }
                    
                }
                case "3" -> {
                    System.out.println("Au revoir !");
                    DatabaseUtils.safelyCloseConnection();
                    return;
                }
                default -> System.out.println("Choix invalide. Réessayez");
            }
        }
    }

    public static void jouer() {
        Scanner input = new Scanner(System.in);
        Board board = new Board();
        GameService gameService = new GameService(); 
        String currentTurn = "J1";

        while (true) {
            board.printBoard();
            String winnerId = board.getWinner();
            if (winnerId != null) {
                Player winner = winnerId.equals("J1") ? getJoueur1() : getJoueur2();
                Player loser = winnerId.equals("J1") ? getJoueur2() : getJoueur1();

                LocalDateTime gameDate = LocalDateTime.now();

                System.out.println("\n==============================================");
                System.out.println("           PARTIE TERMINÉE !");
                System.out.println("    Le gagnant est " + winner.getUsername() + "!");
                System.out.println("==============================================");

                Player updatedWinner = gameService.processWinLoss(winner, loser);

                displayResultsTable(updatedWinner, loser, gameDate);
                break; 
            }

            System.out.println("\nTour de : " + (currentTurn.equals("J1") ? getJoueur1().getUsername() + " (J1)" : getJoueur2().getUsername() + " (J2)"));
            System.out.print("Commande (ex: move 6 0 5 0 ou exit): ");
            String line = input.nextLine();

            if (line.equalsIgnoreCase("exit")) {
                System.out.println("Partie abandonnée !");
                break;
            }

            String[] parts = line.split(" ");
            if (parts.length == 5 && parts[0].equalsIgnoreCase("move")) {
                try {
                    int fromRow = Integer.parseInt(parts[1]);
                    int fromCol = Integer.parseInt(parts[2]);
                    int toRow = Integer.parseInt(parts[3]);
                    int toCol = Integer.parseInt(parts[4]);

                    boolean success = board.moveAnimal(fromRow, fromCol, toRow, toCol, currentTurn);
                    if (success) {
                        currentTurn = currentTurn.equals("J1") ? "J2" : "J1";
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Entrée invalide. Veuillez entrer des chiffres pour les coordonnées.");
                }
            } else {
                System.out.println("Syntaxe invalide. Utilisez : move <ligne_dep> <col_dep> <ligne_arr> <col_arr>");
            }
        }
        
        DatabaseUtils.safelyCloseConnection();
    }

    public static void displayResultsTable(Player updatedWinner, Player loser, LocalDateTime gameDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String formattedDate = gameDate.format(formatter);

        System.out.println("\n\n------------------------ TABLEAU DES SCORES APRÈS LA PARTIE ------------------------");
        System.out.println("------------------------------------------------------------------------------------");
        System.out.printf("%-20s | %-10s | %-10s | %-10s | %-15s%n", "Joueur", "Statut", "Victoires", "Défaites", "Date de la Partie");
        System.out.println("------------------------------------------------------------------------------------");

        System.out.printf("%-20s | %-10s | %-10d | %-10d | %-15s%n",
                updatedWinner.getUsername(),
                "Gagnant",
                updatedWinner.getWins(),
                updatedWinner.getLosses(),
                formattedDate);

        System.out.printf("%-20s | %-10s | %-10d | %-10d | %-15s%n",
                loser.getUsername(),
                "Perdant",
                loser.getWins(),
                loser.getLosses(),
                formattedDate);
                
        System.out.println("------------------------------------------------------------------------------------");
    }

    public static Player getJoueur1() {
        return joueur1;
    }

    public static void setJoueur1(Player joueur1) {
        Main.joueur1 = joueur1;
    }

    public static Player getJoueur2() {
        return joueur2;
    }

    public static void setJoueur2(Player joueur2) {
        Main.joueur2 = joueur2;
    }
}